package com.example.gestionconge.entities.Enumm;

public enum StatutDemande {
    EnAttente , Approuvée , Refusée
}
