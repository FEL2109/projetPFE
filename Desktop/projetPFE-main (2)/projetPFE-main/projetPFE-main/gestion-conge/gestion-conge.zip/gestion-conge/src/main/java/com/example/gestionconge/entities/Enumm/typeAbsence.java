package com.example.gestionconge.entities.Enumm;

public enum typeAbsence {
   Justifiée , NonJustifiée
}
