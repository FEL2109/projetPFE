package com.example.gestionconge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionCongeApplicationTests {

    @Test
    void contextLoads() {
    }

}
