package com.example.gestionconge.entities.Enumm;

public enum typeCongeLibelle {
    CongéAnnuel , CongéMaternité , CongéDeFormation
}
